package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.ActivityOptions;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class location112A extends AppCompatActivity {
    private FusedLocationProviderClient fusedLocationProviderClient;
    private Button getLocationButton, takeLocationButton, stopLocationButton;
    private double latitude, longitude;
    private String currentDateTime;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 100;
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location112);

        stopLocationButton = findViewById(R.id.stopLocation);
        takeLocationButton = findViewById(R.id.Takelocation);
        getLocationButton = findViewById(R.id.Givelocation);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);

        takeLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takelocation();
            }
        });

        getLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

        stopLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopLocationUpdates();
            }
        });
    }

    private void takelocation() {
        Intent intent = new Intent(location112A.this, takelocationmain.class);
        Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        overridePendingTransition(R.anim.fade_zoom, R.anim.fade_out);
        startActivity(intent, bundle);
    }

    private void getLocation() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.getLastLocation()
                    .addOnSuccessListener(new OnSuccessListener<Location>() {
                        @Override
                        public void onSuccess(Location location) {
                            if (location != null) {
                                latitude = location.getLatitude();
                                longitude = location.getLongitude();
                                currentDateTime = getCurrentDateTime();
                                saveLocationToFirebase(latitude, longitude, currentDateTime);

                                Geocoder geocoder = new Geocoder(location112A.this, Locale.getDefault());
                                try {
                                    List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1);
                                    // Handle addresses if needed
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    Toast.makeText(location112A.this, "Error getting address", Toast.LENGTH_SHORT).show();
                                }
                            } else {
                                Toast.makeText(location112A.this, "Location is null", Toast.LENGTH_SHORT).show();
                            }
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            Toast.makeText(location112A.this, "Failed to get location: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

            // Schedule periodic location updates
            handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    fusedLocationProviderClient.getLastLocation()
                            .addOnSuccessListener(new OnSuccessListener<Location>() {
                                @Override
                                public void onSuccess(Location location) {
                                    if (location != null) {
                                        latitude = location.getLatitude();
                                        longitude = location.getLongitude();
                                        currentDateTime = getCurrentDateTime();
                                        saveLocationToFirebase(latitude, longitude, currentDateTime);
                                    }
                                }
                            });
                    handler.postDelayed(this, 3 * 60 * 1000); // Repeat every 3 minutes
                }
            }, 3 * 60 * 1000);

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    stopLocationUpdates();
                }
            }, 60 * 60 * 1000); // Stop after 1 hour
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    private String getCurrentDateTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("E, dd MMM yyyy hh:mm a", Locale.getDefault());
        return sdf.format(new Date());
    }

    private void saveLocationToFirebase(double latitude, double longitude, String dateTime) {
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("locations");

        String key = myRef.push().getKey();
        if (key != null) {
            myRef.child(key).child("latitude").setValue(latitude);
            myRef.child(key).child("longitude").setValue(longitude);
            myRef.child(key).child("datetime").setValue(dateTime);
            Toast.makeText(this, "Location saved to Firebase", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save location to Firebase", Toast.LENGTH_SHORT).show();
        }
    }

    private void stopLocationUpdates() {
        if (handler != null) {
            handler.removeCallbacksAndMessages(null); // Stop all callbacks and messages
            Toast.makeText(this, "Location updates stopped", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "No location updates to stop", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getLocation(); // Call getLocation() if permission is granted
            } else {
                Toast.makeText(this, "Location permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }
}