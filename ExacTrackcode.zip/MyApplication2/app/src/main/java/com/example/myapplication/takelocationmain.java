package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Button;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.content.Context;
public class takelocationmain extends AppCompatActivity {
    private TextView Ofbus, Ofuser, datetimeTextView;
    private Button openMapButton;
    private double userLatitude, userLongitude;

    // Nearest stops data
    private static final double EARTH_RADIUS = 6371;
    private double[] stopLatitudes = {28.6757694, 28.6759025, 28.6766467, 28.6770347, 28.6424608, 28.6787028, 28.6723854, 28.7975536};
    private double[] stopLongitudes = {77.3072762, 77.3189416, 77.3311989, 77.3440051, 77.1754138, 77.3691607, 77.3807902, 77.5343465};
    private String[] stopNames = {"Jhilmil", "Dilshad Garden", "Sahid Nagar", "Raj Bagh", "Rajendra Nagar", "Shyam Park", "Mohan Nagar", "SRMIST"};

    private double buslat,buslong;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_takelocation);

        openMapButton=findViewById(R.id.openMapButton);
        Ofbus = findViewById(R.id.Ofbus);
        Ofuser = findViewById(R.id.Ofuser);
        datetimeTextView = findViewById(R.id.datetime);

        userLatitude = getCurrentLatitude();
        userLongitude = getCurrentLongitude();
        // Calculate the nearest stop to the user's location
        String nearestStopToUser = findNearestStop(userLatitude, userLongitude);
        Ofuser.setText("Nearest stop to user: " + nearestStopToUser);

        DatabaseReference locationsRef = FirebaseDatabase.getInstance().getReference("locations");
        locationsRef.limitToLast(1).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    LocationData locationData = snapshot.getValue(LocationData.class);
                    if (locationData != null) {
                        buslat=locationData.getLatitude();
                        buslong=locationData.getLongitude();
                        Ofbus.setText("Nearest stop to bus " + String.valueOf(findNearestStop(buslat, buslong)));
                        datetimeTextView.setText("Time = "+locationData.getDatetime());

                        // Calculate the nearest stop to the stored location
                        String nearestStopToStoredLocation = findNearestStop(locationData.getLatitude(), locationData.getLongitude());
                        Ofbus.append("\nNearest stop to stored location: " + nearestStopToStoredLocation);

                        // Open Map button click listener
                        openMapButton.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                String uri = "geo:" + locationData.getLatitude() + "," + locationData.getLongitude() + "?q=" + locationData.getLatitude() + "," + locationData.getLongitude();
                                Intent mapIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
                                mapIntent.setPackage("com.google.android.apps.maps");
                                startActivity(mapIntent);
                            }
                        });
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    // Method to find the nearest stop to given latitude and longitude
    private String findNearestStop(double latitude, double longitude) {
        double shortestDistance = Double.MAX_VALUE;
        String nearestStop = "";

        for (int i = 0; i < stopLatitudes.length; i++) {
            double dLat = Math.toRadians(latitude - stopLatitudes[i]);
            double dLon = Math.toRadians(longitude - stopLongitudes[i]);
            double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                    Math.cos(Math.toRadians(latitude)) * Math.cos(Math.toRadians(stopLatitudes[i])) *
                            Math.sin(dLon / 2) * Math.sin(dLon / 2);
            double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
            double distance = EARTH_RADIUS * c;

            if (distance < shortestDistance) {
                shortestDistance = distance;
                nearestStop = stopNames[i];
            }
        }

        return nearestStop;
    }

    private double getCurrentLatitude() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null) {
                return location.getLatitude();
            } else {
                // If GPS provider is not available, you may try NETWORK_PROVIDER or other providers.
                return 0.0; // or any default value
            }
        } catch (SecurityException e) {
            e.printStackTrace();
            return 0.0; // Handle the error as per your requirement
        }
    }

    // Method to get the current longitude using LocationManager
    private double getCurrentLongitude() {
        LocationManager locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        try {
            Location location = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            if (location != null) {
                return location.getLongitude();
            } else {
                // If GPS provider is not available, you may try NETWORK_PROVIDER or other providers.
                return 0.0; // or any default value
            }
        } catch (SecurityException e) {
            e.printStackTrace();
            return 0.0; // Handle the error as per your requirement
        }
    }
}