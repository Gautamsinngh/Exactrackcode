package com.example.myapplication;

public class LocationData {
    private double latitude;
    private double longitude;
    private String datetime;

    // Required default constructor for Firebase
    public LocationData() {
    }

    public LocationData(double latitude, double longitude, String datetime) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.datetime = datetime;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getDatetime() {
        return datetime;
    }

    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }
}
