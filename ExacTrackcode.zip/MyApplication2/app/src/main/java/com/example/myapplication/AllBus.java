package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class AllBus extends AppCompatActivity {

    TextView Bus112A,Bus112,Bus105;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_bus);
        Bus112A=findViewById(R.id.Bus112A);
        Bus112=findViewById(R.id.Bus112);
        Bus105=findViewById(R.id.Bus105);
        Bus112A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bus112a();
            }
        });
        Bus112.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bus112a();
            }
        });
        Bus105.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bus112a();
            }
        });
    }

    private void bus112a() {
        Intent intent=new Intent(AllBus.this,location112A.class);
        Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        overridePendingTransition(R.anim.fade_zoom, R.anim.fade_out);
        startActivity(intent, bundle);
    }
}