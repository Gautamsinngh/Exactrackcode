package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.Dialog;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class BusInfo extends AppCompatActivity {
    Dialog mydialog;
    TextView R112A, R112;
    int defaultColor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_info);
        mydialog = new Dialog(this);
        R112A = findViewById(R.id.R112A);
        R112 = findViewById(R.id.R112);
        defaultColor = ContextCompat.getColor(getApplicationContext(), android.R.color.transparent);

        R112A.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydialog.setContentView(R.layout.pop112a);
                mydialog.show();
            }
        });

        R112.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mydialog.setContentView(R.layout.pop112);
                mydialog.show();
            }
        });
    }
}
