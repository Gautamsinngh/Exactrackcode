package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class HomePage extends AppCompatActivity {

    TextView location,HelpDesk,Logout,info,welcome2;
    FirebaseAuth mAuth;
    FirebaseUser mAuser;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        location=findViewById(R.id.location);
        HelpDesk=findViewById(R.id.HelpDesk);
        Logout=findViewById(R.id.Logout);
        info=findViewById(R.id.info);
        welcome2 = findViewById(R.id.welcome);
        mAuth=FirebaseAuth.getInstance();
        mAuser=mAuth.getCurrentUser();
        if(mAuser!=null){
            String si=mAuser.getEmail();
            welcome2.setText("Welcome, "+si);
        }
        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allBus();
            }
        });
        info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                businfo();

            }
        });
        HelpDesk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                helpdeski();
            }
        });
        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                logout();
            }
        });
    }

    private void logout() {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(HomePage.this, MainActivity.class);
        Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        overridePendingTransition(R.anim.fade_zoom, R.anim.fade_out);
        startActivity(intent, bundle);
        finish();
    }

    private void allBus() {
        Intent intent=new Intent(HomePage.this,AllBus.class);
        Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        overridePendingTransition(R.anim.fade_zoom, R.anim.fade_out);
        startActivity(intent, bundle);
    }    private void helpdeski() {
        Intent intent=new Intent(HomePage.this,helpdesk.class);
        Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        overridePendingTransition(R.anim.fade_zoom, R.anim.fade_out);
        startActivity(intent, bundle);
    }

    private void businfo() {
        Intent intent=new Intent(HomePage.this,BusInfo.class);
        Bundle bundle = ActivityOptions.makeSceneTransitionAnimation(this).toBundle();
        overridePendingTransition(R.anim.fade_zoom, R.anim.fade_out);
        startActivity(intent, bundle);
    }
}